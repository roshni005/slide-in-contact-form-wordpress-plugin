(function ( $ ) {
	"use strict";

	$(function () {

		$( document ).ready(function() {	
			$('#form_header_color').wpColorPicker();
			$('#form_header_border_color').wpColorPicker();
		});
	});

}(jQuery));